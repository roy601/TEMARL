# CAM-LDS full architecture results

Recorded testbed sequences; simulated defender outcomes. No Markov generation.
Dwell counts engaged commands; depth counts distinct engaged technique labels. Protection is simulated.
Each row is a fold and seed. Repeated episodes are not independent campaigns.

| Fold | Seed | Encoder | Learner | Dwell | Depth | Protection % | Actual steps |
|---|---:|---|---|---:|---:|---:|---:|
| 1_autostart_localaccount | 0 | allpos | IPPO | 3.000 | 2.000 | 0.00 | 8 |
| 1_autostart_localaccount | 0 | allpos | MAPPO | 1.000 | 1.000 | 0.00 | 8 |
| 1_autostart_localaccount | 0 | baseline | IPPO | 3.000 | 2.000 | 0.00 | 8 |
| 1_autostart_localaccount | 0 | baseline | MAPPO | 1.000 | 1.000 | 0.00 | 8 |
| 1_autostart_localaccount | 0 | gru_allpos | IPPO | 1.000 | 1.000 | 0.00 | 8 |
| 1_autostart_localaccount | 0 | gru_allpos | MAPPO | 0.000 | 0.000 | 0.00 | 8 |
| 1_autostart_localaccount | 0 | lstm_allpos | IPPO | 1.000 | 1.000 | 0.00 | 8 |
| 1_autostart_localaccount | 0 | lstm_allpos | MAPPO | 1.000 | 1.000 | 0.00 | 8 |
| 1_autostart_localaccount | 0 | NoHistory | IPPO | 2.000 | 2.000 | 0.00 | 8 |
| 1_autostart_localaccount | 0 | NoHistory | MAPPO | 2.000 | 1.000 | 0.00 | 8 |

## Prediction (validation-selected checkpoint and threshold)

| Fold | Seed | Encoder | Micro-F1 % | Macro-F1 % | Exact set % | BCE |
|---|---:|---|---:|---:|---:|---:|
| 1_autostart_localaccount | s0 | allpos | 3.93 | 11.13 | 0.00 | 0.66345 |
| 1_autostart_localaccount | s0 | baseline | 3.93 | 11.17 | 0.00 | 0.66308 |
| 1_autostart_localaccount | s0 | gru_allpos | 4.95 | 7.62 | 0.00 | 0.62374 |
| 1_autostart_localaccount | s0 | lstm_allpos | 3.96 | 8.50 | 0.00 | 0.68285 |

## Training and validation curves

### cells\allpos\1_autostart_localaccount\s0

| Update | Epoch equivalents | Training loss | Validation BCE |
|---:|---:|---:|---:|
| 2 | 0.14 | 0.70946 | 0.66450 |
### cells\baseline\1_autostart_localaccount\s0

| Update | Epoch equivalents | Training loss | Validation BCE |
|---:|---:|---:|---:|
| 2 | 0.14 | 0.71036 | 0.66410 |
### cells\gru_allpos\1_autostart_localaccount\s0

| Update | Epoch equivalents | Training loss | Validation BCE |
|---:|---:|---:|---:|
| 2 | 0.14 | 0.68445 | 0.62314 |
### cells\lstm_allpos\1_autostart_localaccount\s0

| Update | Epoch equivalents | Training loss | Validation BCE |
|---:|---:|---:|---:|
| 2 | 0.14 | 0.72010 | 0.68292 |
### RL allpos 1_autostart_localaccount s0 IPPO

| Update | Train dwell | Validation dwell | Validation depth |
|---:|---:|---:|---:|
| 1 | 0.000 | 2.000 | 1.000 |
### RL allpos 1_autostart_localaccount s0 MAPPO

| Update | Train dwell | Validation dwell | Validation depth |
|---:|---:|---:|---:|
| 1 | 0.000 | 0.000 | 0.000 |
### RL baseline 1_autostart_localaccount s0 IPPO

| Update | Train dwell | Validation dwell | Validation depth |
|---:|---:|---:|---:|
| 1 | 0.000 | 2.000 | 1.000 |
### RL baseline 1_autostart_localaccount s0 MAPPO

| Update | Train dwell | Validation dwell | Validation depth |
|---:|---:|---:|---:|
| 1 | 0.000 | 0.000 | 0.000 |
### RL gru_allpos 1_autostart_localaccount s0 IPPO

| Update | Train dwell | Validation dwell | Validation depth |
|---:|---:|---:|---:|
| 1 | 0.000 | 0.000 | 0.000 |
### RL gru_allpos 1_autostart_localaccount s0 MAPPO

| Update | Train dwell | Validation dwell | Validation depth |
|---:|---:|---:|---:|
| 1 | 0.000 | 0.000 | 0.000 |
### RL lstm_allpos 1_autostart_localaccount s0 IPPO

| Update | Train dwell | Validation dwell | Validation depth |
|---:|---:|---:|---:|
| 1 | 0.000 | 0.000 | 0.000 |
### RL lstm_allpos 1_autostart_localaccount s0 MAPPO

| Update | Train dwell | Validation dwell | Validation depth |
|---:|---:|---:|---:|
| 1 | 0.000 | 0.000 | 0.000 |
### RL NoHistory 1_autostart_localaccount s0 IPPO

| Update | Train dwell | Validation dwell | Validation depth |
|---:|---:|---:|---:|
| 1 | 0.000 | 0.000 | 0.000 |
### RL NoHistory 1_autostart_localaccount s0 MAPPO

| Update | Train dwell | Validation dwell | Validation depth |
|---:|---:|---:|---:|
| 1 | 0.000 | 0.000 | 0.000 |
