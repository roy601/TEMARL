# Uploaded CAM-LDS archive audit

All AttackMate JSONL records parsed. All ZIP member CRCs checked. Other telemetry contents were not semantically inspected. No attack commands executed.

| Check | Result |
|---|---|
| archive | C:\Users\Riton\Downloads\scenario_1_autostart_pam.zip |
| sha256 | 0c11157a2a79ae23a899758ba277e802bf82243b983425f11b8ce39985691d75 |
| zip_entries | 10508 |
| unpacked_bytes | 1060445077 |
| crc_error | None |
| archive_has_attack_times_csv | False |
| attackmate_records | 53 |
| record_types | {'shell': 6, 'sleep': 7, 'msf-module': 2, 'msf-session': 31, 'ssh': 7} |
| labelled_records | 28 |
| extracted_steps | 28 |
| matched | 28 |
| timestamp_adjusted_matches | 1 |
| missing | [] |
| label_mismatches | [] |
| parent_mismatches | [] |
| sidecar_mismatches | [] |
| extra_labelled_records | [] |
| label_instances | 44 |
| unique_parent_labels | 26 |
| multi_label_steps | 5 |
| csv_order_matches_execution | True |

This checks one supplied archive against the existing corpus. It does not establish authenticity against a publisher checksum or certify every other archive.
The extractor needs the separately released authors' attack_times.csv; this ZIP alone is not its complete input. Labels are execution metadata, not detector predictions.